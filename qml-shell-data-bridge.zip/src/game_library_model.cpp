#include "game_library_model.h"
#include "library_sync_worker.h"

GameLibraryModel::GameLibraryModel(QObject *parent) : QAbstractListModel(parent)
{
    m_worker = new LibrarySyncWorker();
    m_worker->moveToThread(&m_workerThread);

    connect(&m_workerThread, &QThread::finished, m_worker, &QObject::deleteLater);
    connect(m_worker, &LibrarySyncWorker::gameReady, this, &GameLibraryModel::onGameReady);
    connect(m_worker, &LibrarySyncWorker::installStateChanged, this, &GameLibraryModel::onInstallStateChanged);
    connect(m_worker, &LibrarySyncWorker::syncFinished, this, &GameLibraryModel::onSyncFinished);
    connect(m_worker, &LibrarySyncWorker::syncFailed, this, &GameLibraryModel::syncFailed);

    m_workerThread.start();
}

GameLibraryModel::~GameLibraryModel()
{
    m_workerThread.quit();
    m_workerThread.wait();
}

int GameLibraryModel::rowCount(const QModelIndex &parent) const
{
    if (parent.isValid())
        return 0;
    return m_games.size();
}

QVariant GameLibraryModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() < 0 || index.row() >= m_games.size())
        return {};

    const GameEntry &g = m_games.at(index.row());
    switch (role) {
    case AppIdRole:      return g.appId;
    case NameRole:       return g.name;
    case PlaytimeRole:   return g.playtimeMinutes;
    case InstalledRole:  return g.installed;
    case BoxArtPathRole: return g.boxArtPath;
    default:             return {};
    }
}

QHash<int, QByteArray> GameLibraryModel::roleNames() const
{
    return {
        {AppIdRole, "appId"},
        {NameRole, "name"},
        {PlaytimeRole, "playtime"},
        {InstalledRole, "installed"},
        {BoxArtPathRole, "boxArtPath"},
    };
}

void GameLibraryModel::refresh()
{
    if (m_syncing)
        return;
    m_syncing = true;
    emit syncingChanged();
    QMetaObject::invokeMethod(m_worker, "startSync", Qt::QueuedConnection);
}

void GameLibraryModel::onGameReady(const GameEntry &entry)
{
    const int idx = indexForAppId(entry.appId);
    if (idx >= 0) {
        m_games[idx] = entry;
        const QModelIndex modelIdx = index(idx);
        emit dataChanged(modelIdx, modelIdx);
    } else {
        beginInsertRows(QModelIndex(), m_games.size(), m_games.size());
        m_games.append(entry);
        endInsertRows();
    }
}

void GameLibraryModel::onInstallStateChanged()
{
    // Simplest correct approach for now: a full re-sync keeps installed
    // flags accurate. Box art is already cached per-appid on disk, so this
    // doesn't re-download art -- ArtworkClient would need a "skip if cached"
    // check to make this cheap, worth adding once this is a bottleneck.
    refresh();
}

void GameLibraryModel::onSyncFinished()
{
    m_syncing = false;
    emit syncingChanged();
}

int GameLibraryModel::indexForAppId(qint64 appId) const
{
    for (int i = 0; i < m_games.size(); ++i) {
        if (m_games.at(i).appId == appId)
            return i;
    }
    return -1;
}
