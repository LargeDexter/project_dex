#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>

#include "game_library_model.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    GameLibraryModel gameLibrary;

    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty("gameLibrary", &gameLibrary);

    QObject::connect(
        &engine, &QQmlApplicationEngine::objectCreationFailed,
        &app, []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    engine.loadFromModule("ProjectDex", "Main");

    gameLibrary.refresh(); // auto-sync on launch, per the plan

    return app.exec();
}
