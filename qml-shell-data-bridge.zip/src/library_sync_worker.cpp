#include "library_sync_worker.h"
#include "steam_client.h"
#include "library_scanner.h"
#include "artwork_client.h"

#include <QProcessEnvironment>
#include <QSet>

LibrarySyncWorker::LibrarySyncWorker(QObject *parent) : QObject(parent)
{
    qRegisterMetaType<GameEntry>();
}

LibrarySyncWorker::~LibrarySyncWorker() = default;

void LibrarySyncWorker::startSync()
{
    const QProcessEnvironment env = QProcessEnvironment::systemEnvironment();
    const QString steamApiKey = env.value("STEAM_API_KEY");
    const QString steamId = env.value("STEAM_ID");
    const QString gridDbKey = env.value("STEAMGRIDDB_API_KEY"); // may be empty -- artwork client falls back to Steam CDN

    if (steamApiKey.isEmpty() || steamId.isEmpty()) {
        emit syncFailed("STEAM_API_KEY and/or STEAM_ID are not set in the environment.");
        emit syncFinished();
        return;
    }

    if (!m_steamClient)
        m_steamClient = new SteamClient(steamApiKey, steamId, this);
    if (!m_libraryScanner)
        m_libraryScanner = new LibraryScanner(this);
    if (!m_artworkClient)
        m_artworkClient = new ArtworkClient(gridDbKey, this);

    QList<OwnedGame> owned;
    QString ownedError;
    if (!m_steamClient->fetchOwnedGames(owned, ownedError)) {
        emit syncFailed("Steam sync failed: " + ownedError);
        emit syncFinished();
        return;
    }

    QSet<qint64> installedIds;
    if (m_libraryScanner->discoverLibraries()) {
        const QList<InstalledApp> installedApps = m_libraryScanner->scanInstalledApps();
        for (const InstalledApp &a : installedApps)
            installedIds.insert(a.appId);

        if (!m_watchingStarted) {
            connect(m_libraryScanner, &LibraryScanner::installChanged,
                    this, &LibrarySyncWorker::installStateChanged);
            m_libraryScanner->startWatching();
            m_watchingStarted = true;
        }
    }

    for (const OwnedGame &g : owned) {
        GameEntry entry;
        entry.appId = g.appId;
        entry.name = g.name;
        entry.playtimeMinutes = g.playtimeForeverMinutes;
        entry.installed = installedIds.contains(g.appId);

        QString artError;
        bool usedFallback = false;
        entry.boxArtPath = m_artworkClient->fetchAndCacheBoxArt(g.appId, g.name, usedFallback, artError);
        // Empty boxArtPath means both SteamGridDB and the CDN fallback
        // failed for this one game -- QML shows a placeholder tile for it.

        emit gameReady(entry);
    }

    emit syncFinished();
}
