#pragma once

#include <QAbstractListModel>
#include <QThread>
#include "game_entry.h"

class LibrarySyncWorker;

// The single source of truth QML binds to. Owns a background thread running
// LibrarySyncWorker; this class itself does no blocking work and no network
// or filesystem I/O -- it just holds the merged game list and reacts to
// signals from the worker.
class GameLibraryModel : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(bool syncing READ isSyncing NOTIFY syncingChanged)

public:
    enum Roles {
        AppIdRole = Qt::UserRole + 1,
        NameRole,
        PlaytimeRole,
        InstalledRole,
        BoxArtPathRole,
    };

    explicit GameLibraryModel(QObject *parent = nullptr);
    ~GameLibraryModel() override;

    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;

    bool isSyncing() const { return m_syncing; }

public slots:
    // Callable from QML (e.g. a Refresh button) as well as internally.
    // No-op if a sync is already in progress.
    void refresh();

signals:
    void syncingChanged();
    void syncFailed(const QString &error);

private slots:
    void onGameReady(const GameEntry &entry);
    void onInstallStateChanged();
    void onSyncFinished();

private:
    QList<GameEntry> m_games;
    QThread m_workerThread;
    LibrarySyncWorker *m_worker = nullptr;
    bool m_syncing = false;

    int indexForAppId(qint64 appId) const;
};
