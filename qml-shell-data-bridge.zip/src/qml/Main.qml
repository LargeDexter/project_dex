import QtQuick
import QtQuick.Window
import QtQuick.Controls
import ProjectDex

Window {
    width: 1280
    height: 720
    visible: true
    title: "Project Dex"
    color: Theme.background

    Column {
        anchors.fill: parent
        anchors.margins: Theme.spacingLarge
        spacing: Theme.spacingMedium

        Row {
            spacing: Theme.spacingMedium

            Text {
                text: gameLibrary.syncing
                      ? "Syncing..."
                      : ("Library (" + gridView.count + " games)")
                color: Theme.textPrimary
                font.pixelSize: Theme.fontSizeMedium
            }

            Button {
                text: "Refresh"
                enabled: !gameLibrary.syncing
                onClicked: gameLibrary.refresh()
            }
        }

        GridView {
            id: gridView
            width: parent.width
            height: parent.height - 60
            cellWidth: 200
            cellHeight: 260
            model: gameLibrary
            clip: true

            delegate: Rectangle {
                width: 180
                height: 240
                radius: Theme.radiusMedium
                color: Theme.surface

                Column {
                    anchors.fill: parent
                    anchors.margins: 8
                    spacing: 6

                    Image {
                        width: parent.width
                        height: 180
                        source: boxArtPath.length > 0 ? ("file://" + boxArtPath) : ""
                        fillMode: Image.PreserveAspectCrop
                        asynchronous: true

                        Rectangle {
                            anchors.fill: parent
                            visible: parent.status !== Image.Ready
                            color: Theme.surfaceHighlight
                            radius: Theme.radiusSmall
                        }
                    }

                    Text {
                        width: parent.width
                        text: name
                        color: Theme.textPrimary
                        font.pixelSize: Theme.fontSizeSmall
                        wrapMode: Text.WordWrap
                        elide: Text.ElideRight
                        maximumLineCount: 2
                    }

                    Text {
                        text: installed ? "Installed" : "Not installed"
                        color: installed ? Theme.accent : Theme.textSecondary
                        font.pixelSize: 11
                    }
                }
            }
        }
    }
}
